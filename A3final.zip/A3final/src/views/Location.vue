<script setup>
import Map from '@/components/Map.vue';
</script>
<template>
  <div>
    <Map></Map>
  </div>
</template>

<style scoped>
div {
  padding: 10px;
}
</style>
