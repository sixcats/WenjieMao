<script setup>

</script>

<template>
  <div class="welcome-card">
    <div>Welcome to our</div>
    <div>website!</div>
    <div>We are glad to have you here!</div>
    <div>view our latest activities</div>
  </div>
</template>

<style scoped>
.welcome-card{
  background: #e7ebec;
  border-radius: 10px;
  padding: 40px 20px;
}
</style>
