<script setup>

import CustomHeader from "@/components/CustomHeader.vue";
import {Food, House, User, Warning} from "@element-plus/icons-vue";
</script>

<template>

 <div class="layout">
   <custom-header></custom-header>
   <div class="custom-nav">
     <div class="nav-item">
       <el-icon><House /></el-icon>
       <div class="nav-item-text">Home</div>
     </div>
     <div class="nav-item">
       <el-icon><User /></el-icon>
       <div class="nav-item-text">Volunteers</div>
     </div>
     <div class="nav-item">
       <el-icon><Food /></el-icon>
       <div class="nav-item-text">Donate</div>
     </div>
     <div class="nav-item">
       <el-icon><Warning /></el-icon>
       <div class="nav-item-text">About Us</div>
     </div>
   </div>
 </div>

</template>

<style scoped lang="scss">

.custom-nav{
  display: flex;
  width: 100%;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  .nav-item{
    flex: 1;
    width: 0;
    display: flex;
    align-items: center;
  }
}
</style>
