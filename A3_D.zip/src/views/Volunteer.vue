<script lang="ts" setup>
import {
  Iphone,
  Location,
  OfficeBuilding,
  User,
} from '@element-plus/icons-vue'
import type { ComponentSize } from 'element-plus'
import { computed, ref } from "vue";

const currentPage = ref(1)
const pageSize = ref(10)
const queryForm = ref({
  username: ''
})
const volunteers = ref([
  {
    name: 'volunteer 1', img: '/pictures/volunteer/img.png',
    telephone: "0421234567",
    place: "Melbourne",
    address: "Melbourne central"
  },
  {
    name: 'volunteer 2', img: '/pictures/volunteer/img.png',
    telephone: "0421234567",
    place: "Melbourne",
    address: "Melbourne central"
  },
  {
    name: 'volunteer 3', img: '/pictures/volunteer/img.png',
    telephone: "0421234567",
    place: "Melbourne",
    address: "Melbourne central"
  },
  {
    name: 'volunteer 4', img: '/pictures/volunteer/img.png',
    telephone: "0421234567",
    place: "Melbourne",
    address: "Melbourne central"
  },
])
const tableData = ref(volunteers.value.slice(0, pageSize.value))
const userInfo = ref({})
const size = ref<ComponentSize>('default')
const iconStyle = computed(() => {
  const marginMap = {
    large: '8px',
    default: '6px',
    small: '4px',
  }
  return {
    marginRight: marginMap[size.value] || marginMap.default,
  }
})
//control dialog
const dialogVisible = ref(false)
const handleClose = () => {
  dialogVisible.value = false
}

const search = () => {
  if (!queryForm.value.username) {
    tableData.value = volunteers.value
    return
  }
  tableData.value = volunteers.value.filter((item) => item.name === queryForm.value.username)
}

const deleteRow = (index: number) => {
  volunteers.value.splice(index, 1)
  tableData.value = volunteers.value.slice(0, pageSize.value)
}
const viewRow = (scope) => {
  userInfo.value = scope.row
  dialogVisible.value = true
}
const handleSizeChange = (val) => {
  tableData.value = volunteers.value.slice(0, val)
}
const handleCurrentChange = (val) => {
  tableData.value = volunteers.value.slice((val - 1) * pageSize.value, val * pageSize.value)
}

</script>

<template>
  <div class="container">
    <el-row :gutter="24">
      <el-col :span="24">
        Username:
        <el-input style="width: 150px;" v-model="queryForm.username" placeholder="Enter username"></el-input>
        <el-button type="primary" @click="search">Search</el-button>
      </el-col>
      <!-- <el-col :span="4">
        <el-button type="danger" @click="saveDialogVisible = true">Add</el-button>
      </el-col> -->
    </el-row>
    <el-divider />
    <el-table :data="tableData" style="width: 100%" :default-sort="{ prop: 'name', order: 'descending' }">
      <el-table-column fixed type="index" width="50" />
      <el-table-column prop="name" label="name" width="110" sortable />
      <el-table-column prop="telephone" label="telephone" width="120" />
      <el-table-column prop="place" label="place" width="200" />
      <el-table-column prop="address" label="address" width="110" />
      <el-table-column fixed="right" label="Operations" min-width="120">
        <template #default="scope">
          <el-button link type="primary" size="small" @click.prevent="deleteRow(scope.$index)">
            Remove
          </el-button>
          <el-button link type="primary" size="small" @click.prevent="viewRow(scope)">
            View
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[10, 20, 30, 50]"
      :size="10" :disabled="false" layout="total, sizes, prev, pager, next, jumper" :total="volunteers.length"
      @size-change="handleSizeChange" @current-change="handleCurrentChange" style="padding-top:1%;padding-bottom:5%" />
    <!-- <div class="info" v-for="item in volunteers">
      <img :src="item.img" style="width: 100%;border-radius: 10px 10px 0 0;">
      <h2 style="text-align: center">{{ item.name }}</h2>
      <div class="btnC">
        <el-button @click="handleClick(item)" type="primary">View Detail</el-button>
      </div>
    </div> -->
    <!-- show detail-->
    <el-dialog v-model="dialogVisible" title="" width="700" :before-close="handleClose">
      <el-descriptions title="User Info" direction="vertical" border style="margin-top: 20px">
        <el-descriptions-item :rowspan="2" :width="140" label="Photo" align="center">
          <el-image style="width: 100px; height: 100px" :src="userInfo.img" />
        </el-descriptions-item>
        <el-descriptions-item>
          <template #label>
            <div class="cell-item">
              <el-icon :style="iconStyle">
                <user />
              </el-icon>
              Username
            </div>
          </template>
          {{ userInfo.name }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template #label>
            <div class="cell-item">
              <el-icon :style="iconStyle">
                <iphone />
              </el-icon>
              Telephone
            </div>
          </template>
          {{ userInfo.telephone }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template #label>
            <div class="cell-item">
              <el-icon :style="iconStyle">
                <office-building />
              </el-icon>
              Place
            </div>
          </template>
          {{ userInfo.place }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template #label>
            <div class="cell-item">
              <el-icon :style="iconStyle">
                <location />
              </el-icon>
              Address
            </div>
          </template>
          {{ userInfo.address }}
        </el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">Close</el-button>
        </div>
      </template>
    </el-dialog>
  </div>

</template>

<style scoped lang="scss">
.container {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 10px;

  .info {
    width: 30%;
    border: 1px solid #d5d9d4;
    border-radius: 10px;
    padding-bottom: 10px;
  }
}

.btnC {
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
</style>
