export const RES_SUCCESS_CODE = 0;

export const AUTH_FAIL_CODE = 401;

export const TOKEN_KEY = 'access_token';
