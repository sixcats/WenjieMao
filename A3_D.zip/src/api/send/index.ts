import request from '@/utils/http';
export const send = (data?): Promise<IResponse> => {
    return request.post({
        url: '/v3/mail/send',
        data,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer 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'
        }
    });
};