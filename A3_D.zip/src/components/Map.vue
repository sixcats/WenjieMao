<template>
    <GoogleMap :api-promise="apiPromise" style="width: 100%; height: 500px" :center="center" :zoom="15">
        <Marker :options="{ position: center }" />
    </GoogleMap>
</template>

<script>
import { ref } from 'vue'
import { GoogleMap, Marker } from 'vue3-google-map'
import { Loader } from '@googlemaps/js-api-loader';

let apiPromise = null
export default {
    components: { GoogleMap, Marker },
    data() {
        return {
        }
    },
    setup() {
        const center = ref({ lat: 34.0902871, lng: -118.37869 })
        const loader = new Loader({
            apiKey: 'AIzaSyCf7QJKKMGq0O3jA0UKef-AvlDWOnGZMg8',
            version: 'weekly',
            libraries: ['places'], 
        })
        apiPromise = loader.load();
        function handleDragEnd(e) {
            center.value = { lat: e.latLng.lat(), lng: e.latLng.lng() }
        }
        return { center, handleDragEnd }
    }
}
</script>