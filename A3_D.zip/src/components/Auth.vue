<template>
  <div>
    <h1>用户认证</h1>
    <form @submit.prevent="handleLogin">
      <input v-model="email" type="email" placeholder="电子邮件" required />
      <input v-model="password" type="password" placeholder="密码" required />
      <button type="submit">登录</button>
    </form>
    <button @click="handleRegister">注册</button>
  </div>
</template>

<script>
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../auth/firebase';

export default {
  data() {
    return {
      email: '',
      password: '',
    };
  },
  methods: {
    async handleLogin() {
      try {
        await signInWithEmailAndPassword(auth, this.email, this.password);
        alert('登录成功');
      } catch (error) {
        console.error('登录失败:', error);
        alert(error.message);
      }
    },
    async handleRegister() {
      try {
        await createUserWithEmailAndPassword(auth, this.email, this.password);
        alert('注册成功');
      } catch (error) {
        console.error('注册失败:', error);
        alert(error.message);
      }
    },
  },
};
</script>

<style scoped>
form {
  margin-bottom: 20px;
}

input {
  display: block;
  margin: 10px 0;
  padding: 10px;
  width: 200px;
}

button {
  padding: 10px 15px;
}
</style>