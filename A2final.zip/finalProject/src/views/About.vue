<script setup>

</script>

<template>
<div>
  <h1>About Us</h1>
  <div>This project aims to develop a modern web application for a well-known health 
    charity dedicated to improving the well-being of older people.</div>
   <div> The web application 
aims to leverage advanced technology, expand the charity's reach, enhance access to 
resources, and ultimately improve the quality of life for seniors.</div>
   <div>Guided by the 
charity's mission, the program aims to provide critical health information, support 
services, educational content, and a streamlined donation process, presented in a userfriendly and easily accessible manner.</div>
  <el-divider></el-divider>
  <h1>Our Vision</h1>
  <div>The main goals of the web application are to provide comprehensive and easily 
accessible information on health services, provide self-assessment and health 
monitoring tools, create a community space where older users can connect with others 
who have had similar experiences, and provide a seamless donation experience.</div>
<div> By 
addressing the specific needs of older age groups and incorporating user-friendly 
donation capabilities, the web application will play a key role in advancing the 
charity's mission to improve the health and well-being of vulnerable populations</div>


<div>Together, we can make a difference and build a brighter future for all.</div>


</div>
</template>

<style scoped>
div {
  padding: 10px;
}
</style>
