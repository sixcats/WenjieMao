import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import FireBaseSigninView from '@/views/FireBaseSigninView.vue'
import FireBaseRegisterView from '@/views/FireBaseRegisterView.vue'
import AddBookView from '@/views/AddBookView.vue'

const routes = [

  {
    path: '/',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'About',
    component: AboutView
  },
  {
    path: '/FireLogin',
    name: 'FireLogin',
    component: FireBaseSigninView
  },
  {
    path: '/FireRegister',
    name: 'FireRegister',
    component: FireBaseRegisterView
  },
  {
    path:'/addbook',
    name:'AddBook',
    component: AddBookView
  }

  

]



const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router