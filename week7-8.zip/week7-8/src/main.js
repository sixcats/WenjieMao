
import 'bootstrap/dist/css/bootstrap.min.css'

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

import PrimeVue from 'primevue/config'
import Aura from '@primevue/themes/aura'


const app = createApp(App)
app.use(PrimeVue, { theme: { preset: Aura } })
app.use(router)
app.mount('#app')

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJgg2A0AaFGaKg11I9pYozmKypd8HFxbE",
  authDomain: "week7-wenjie.firebaseapp.com",
  projectId: "week7-wenjie",
  storageBucket: "week7-wenjie.appspot.com",
  messagingSenderId: "570249966700",
  appId: "1:570249966700:web:b0606afb99ae20be289449"
};

// Initialize Firebase
initializeApp(firebaseConfig);
const db = getFirestore()
export default db

